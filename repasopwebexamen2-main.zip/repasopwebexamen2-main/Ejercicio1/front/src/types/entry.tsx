export interface Entry {
  id?: number;
  title: string;
  category: string;
  author: string;
}